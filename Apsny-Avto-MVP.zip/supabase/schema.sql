-- Apsny Avto: run this in Supabase SQL Editor.
create extension if not exists pgcrypto;
create table if not exists public.cars (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  brand text not null default 'Другое',
  model text not null,
  year integer not null check (year between 1950 and 2027),
  price numeric not null check (price > 0),
  city text not null check (city in ('Сухум','Гагра','Гудаута','Новый Афон','Очамчыра','Ткуарчал','Гал','Пицунда')),
  mileage integer not null default 0 check (mileage >= 0),
  fuel text not null default 'Бензин',
  transmission text not null default 'Автомат',
  phone text not null,
  description text not null default '',
  image_url text not null default '',
  status text not null default 'published' check (status in ('published','hidden','sold')),
  created_at timestamptz not null default now()
);
alter table public.cars enable row level security;
drop policy if exists "Anyone can read published cars" on public.cars;
create policy "Anyone can read published cars" on public.cars for select using (status = 'published');
drop policy if exists "Anyone can publish cars" on public.cars;
create policy "Anyone can publish cars" on public.cars for insert with check (status = 'published');
grant select, insert on public.cars to anon, authenticated;
