import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "Apsny Avto — автомобили Абхазии", description: "Покупка и продажа автомобилей по всей Абхазии." };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="ru"><body>{children}</body></html>;
}