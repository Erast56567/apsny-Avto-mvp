# Apsny Avto

Responsive Russian-language car marketplace MVP for Abkhazia (Sukhum, Gagra, Gudauta, New Athos, Ochamchira, Tkuarchal, Gal, Pitsunda).

## What works
- Responsive car listing catalogue and filters by search, city and max price
- Listing detail and click-to-call contact
- Add listing form with basic validation
- Supabase-backed public listings when configured
- Demo listings when running without Supabase

## Important
This source package is **not yet a publicly deployed service**. A live shared marketplace needs a Supabase project and a hosting deployment (for example Vercel). Without Supabase, new listings only exist in the current browser session and are not shared between visitors. Demo listings are illustrative, not real offers. Replace/remove them before launch.

## Run locally
1. Install Node.js 20 or newer.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env.local`.
4. Create a Supabase project and copy its Project URL and anon/public key into `.env.local`.
5. In Supabase SQL Editor run `supabase/schema.sql`.
6. Run `npm run dev` and open http://localhost:3000.

If you skip step 3-5, the catalogue opens with demo content, but listing creation is local only.

## Publish online
1. Push this project to a Git repository.
2. Import the repository into Vercel.
3. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY` in Vercel project environment variables.
4. Deploy and test creating a listing from a second device.

## Before public launch
The supplied schema intentionally keeps the first version simple. Public insert is enabled to reduce friction, so spam is possible. Before promoting the site widely, add CAPTCHA/rate limiting, image upload with size/type validation, listing moderation, reporting, edit/delete ownership, privacy/terms pages, and backups. Never put a Supabase service-role key in frontend environment variables. Consider phone-number privacy and local legal requirements.
